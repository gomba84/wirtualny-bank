# Wymagania

Aplikacja wymaga środowiska NodeJS w wersji 6 lub większej.

# Instalacja

Po wejściu do katalogu zawierającego plik package.json wykonaj polecenie

npm install

# Uruchomienie

Aplikację uruchomić można za pomocą polecenia

npm start -- --port 3009

gdzie port jest parametrem, ktory oznacza port, na jakim zostanie uruchomiona aplikacja.
